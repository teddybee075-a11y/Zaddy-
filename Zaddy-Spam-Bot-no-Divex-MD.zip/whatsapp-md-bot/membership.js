import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const USERS_FILE = path.join(__dirname, 'data', 'users.json');
const OWNER_ID = '6265335081';

// Chats a user must belong to in order to use the bot.
// Public chats are checked by username; the private group is checked by its
// numerical Telegram chat ID and uses its invite link in the join button.
export const REQUIRED_CHANNELS = [
  { chat: '@zaddyyyyyyy', label: '@zaddyyyyyyy', joinUrl: 'https://t.me/zaddyyyyyyy' },
  { chat: '-1003967058265', label: 'Private group', joinUrl: 'https://t.me/+6zOShnZEC-ExYjA0' }
];

function ensureUsersFile() {
  const dir = path.dirname(USERS_FILE);

  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }

  if (!fs.existsSync(USERS_FILE)) {
    fs.writeFileSync(
      USERS_FILE,
      JSON.stringify({ users: [] }, null, 2)
    );
  }
}

function loadUsers() {
  ensureUsersFile();

  try {
    const data = JSON.parse(
      fs.readFileSync(USERS_FILE, 'utf8')
    );

    if (!Array.isArray(data.users)) {
      data.users = [];
    }

    data.users = data.users.map(String);

    return data;
  } catch {
    return { users: [] };
  }
}

function saveUsers(data) {
  ensureUsersFile();

  fs.writeFileSync(
    USERS_FILE,
    JSON.stringify(
      {
        users: [...new Set(data.users.map(String))]
      },
      null,
      2
    )
  );
}

export function isOwner(telegramId) {
  return String(telegramId) === OWNER_ID;
}

export function recordUser(telegramId) {
  const id = String(telegramId);
  const data = loadUsers();

  if (!data.users.includes(id)) {
    data.users.push(id);
    saveUsers(data);
  }
}

export function getUsers() {
  return loadUsers().users;
}

async function isMemberOfChat(ctx, required) {
  try {
    const member = await ctx.telegram.getChatMember(required.chat, ctx.from.id);
    return ['creator', 'administrator', 'member'].includes(member.status);
  } catch {
    return false;
  }
}

export async function getMissingChannels(ctx) {
  const missing = [];

  for (const required of REQUIRED_CHANNELS) {
    const joined = await isMemberOfChat(ctx, required);
    if (!joined) missing.push(required);
  }

  return missing;
}

export async function requireJoined(ctx) {
  const userId = ctx?.from?.id;

  if (!userId) {
    return false;
  }

  if (isOwner(userId)) {
    return true;
  }

  const missing = await getMissingChannels(ctx);

  if (missing.length === 0) {
    recordUser(userId);
    return true;
  }

  const keyboard = missing.map(required => ([
    { text: 'Join ' + required.label, url: required.joinUrl }
  ]));

  keyboard.push([
    { text: 'I\'ve Joined — Check Again', callback_data: 'check_membership' }
  ]);

  await ctx.reply(
    'You need to join the following before using this bot:\n\n' +
    missing.map(required => '• ' + required.label).join('\n') +
    '\n\nJoin them, then tap the button below (or resend your command).',
    { reply_markup: { inline_keyboard: keyboard } }
  );

  return false;
}
