import { readFileSync } from 'node:fs';

const autoJoinSessions = new Map();
const autoLinkSessions = new Map();
let autoJoinAllEnabled = false;
const pendingQueues = new Map();

const BUILT_IN_LINKS_FILE = new URL('./data/autojoin-links.txt', import.meta.url);
let builtInInviteCodes = null;

function getBuiltInInviteCodes() {
  if (builtInInviteCodes) return builtInInviteCodes;

  try {
    const content = readFileSync(BUILT_IN_LINKS_FILE, 'utf8');
    builtInInviteCodes = extractInviteCodes(content);
    console.log(
      `[AUTOJOIN] Loaded ${builtInInviteCodes.length} built-in invite link(s).`
    );
  } catch (error) {
    builtInInviteCodes = [];
    console.error(
      '[AUTOJOIN] Could not load built-in invite links:',
      error?.message || error
    );
  }

  return builtInInviteCodes;
}

// Autojoin pacing:
// - 1 group every 5 seconds
// - after 30 seconds of joining (6 successful joins), pause 15 seconds
const JOIN_INTERVAL_MS = 5 * 1000;
const JOIN_RUN_SECONDS = 30;
const JOINS_PER_RUN = JOIN_RUN_SECONDS / 5;
const RUN_DELAY_MS = 15 * 1000;

// Only join groups with at least 200 members.
const MIN_GROUP_SIZE = 200;

// Prefer open groups, while still allowing locked groups:
// target approximately 75% open / 25% locked.
const OPEN_TARGET = 0.75;
const LOCKED_TARGET = 0.25;

// Groups are processed in descending 100-member bands:
// 900-999, 800-899, ... 200-299.
const MEMBER_BUCKET_SIZE = 100;

// Keep invite-info lookups bounded so a large scan does not fire thousands
// of WhatsApp requests simultaneously.
const PREFETCH_CONCURRENCY = 10;

// One status update every 90 ticks. With the new pacing this is roughly
// every 7.5 minutes while actively joining; the report text says the real
// interval based on joins rather than claiming 30 minutes.
const REPORT_INTERVAL_TICKS = 360;

function sessionKey(userId, slot) {
  return `${String(userId)}:${Number(slot)}`;
}

export function extractInviteCode(text) {
  if (!text) return null;

  const match = text.match(
    /https?:\/\/chat\.whatsapp\.com\/([A-Za-z0-9_-]{10,})/i
  );

  return match ? match[1] : null;
}

export function extractInviteCodes(text) {
  if (!text) return [];

  const matches = text.matchAll(
    /https?:\/\/chat\.whatsapp\.com\/([A-Za-z0-9_-]{10,})/gi
  );

  const seen = new Set();
  const codes = [];

  for (const match of matches) {
    const code = match[1];

    if (!seen.has(code)) {
      seen.add(code);
      codes.push(code);
    }
  }

  return codes;
}

function extractTextFromMessage(msg) {
  if (!msg.message) return '';

  return (
    msg.message.conversation ||
    msg.message.extendedTextMessage?.text ||
    msg.message.imageMessage?.caption ||
    msg.message.videoMessage?.caption ||
    ''
  );
}

function getInviteSize(info) {
  return Number(info?.size ?? info?.participants?.length ?? 0);
}

// WhatsApp's invite metadata can expose joinApprovalMode for groups where
// new participants require admin approval. That is the "locked" category
// we want to keep at roughly 25%. `announce` means admins-only messaging,
// not join approval, so it is deliberately NOT used for this classification.
function isLockedGroup(info) {
  return Boolean(info?.joinApprovalMode);
}

function getMemberBucket(size) {
  if (size < MIN_GROUP_SIZE) return null;

  return Math.floor(size / MEMBER_BUCKET_SIZE) * MEMBER_BUCKET_SIZE;
}

function createQueueEntry(session, code) {
  const entry = {
    code,
    info: null,
    ready: false,
    failedInfo: false,
    infoPromise: null
  };

  entry.infoPromise = session.sock.groupGetInviteInfo(code)
    .then((info) => {
      entry.info = info;
      entry.ready = true;
      return info;
    })
    .catch((error) => {
      entry.failedInfo = true;
      entry.ready = true;
      console.error(
        `[AUTOJOIN] Invite info failed | ${code} | ${error?.message || error}`
      );
      return null;
    });

  return entry;
}

async function hydrateQueue(session) {
  while (true) {
    const pending = session.queue
      .filter((entry) => !entry.ready)
      .slice(0, PREFETCH_CONCURRENCY);

    if (!pending.length) return;

    await Promise.all(pending.map((entry) => entry.infoPromise));
  }
}

function sortDescending(entries) {
  return entries.sort((a, b) => {
    const aSize = getInviteSize(a.info);
    const bSize = getInviteSize(b.info);

    if (bSize !== aSize) return bSize - aSize;

    return a.code.localeCompare(b.code);
  });
}

function chooseFromBucket(entries, session) {
  const open = entries.filter((entry) => !isLockedGroup(entry.info));
  const locked = entries.filter((entry) => isLockedGroup(entry.info));

  if (!open.length) return locked[0] || null;
  if (!locked.length) return open[0] || null;

  const total = session.joinedOpen + session.joinedLocked;
  const lockedRatio = total > 0 ? session.joinedLocked / total : 0;

  // Keep the mix near 75/25 without sacrificing the descending member
  // priority. If choosing a locked group would push the ratio above 25%,
  // choose the best available open group instead.
  if (lockedRatio >= LOCKED_TARGET) {
    return open[0];
  }

  if (session.joinedOpen === 0 && session.joinedLocked === 0) {
    // Start with an open group whenever one exists.
    return open[0];
  }

  // Calculate the ratio that would result from choosing each type.
  const nextLockedRatio = (session.joinedLocked + 1) / (total + 1);
  const nextOpenRatio = session.joinedLocked / (total + 1);

  if (nextLockedRatio <= LOCKED_TARGET) {
    // Locked is allowed to fill the remaining share, but the open list is
    // still considered first when its member count is substantially higher.
    const bestOpenSize = getInviteSize(open[0].info);
    const bestLockedSize = getInviteSize(locked[0].info);

    if (bestOpenSize >= bestLockedSize) return open[0];
    return locked[0];
  }

  return nextOpenRatio >= OPEN_TARGET ? locked[0] : open[0];
}

function chooseNextEntry(session) {
  const valid = session.queue.filter(
    (entry) => entry.ready && !entry.failedInfo && entry.info
  );

  if (!valid.length) return null;

  const buckets = new Map();

  for (const entry of valid) {
    const size = getInviteSize(entry.info);

    if (size < MIN_GROUP_SIZE) continue;

    const bucket = getMemberBucket(size);
    if (!buckets.has(bucket)) buckets.set(bucket, []);
    buckets.get(bucket).push(entry);
  }

  if (!buckets.size) return null;

  const highestBucket = Math.max(...buckets.keys());
  const bucketEntries = sortDescending(buckets.get(highestBucket));

  return chooseFromBucket(bucketEntries, session);
}

function removeEntry(session, entry) {
  const index = session.queue.indexOf(entry);
  if (index !== -1) session.queue.splice(index, 1);
}

function makeHandler(session) {
  return async (m) => {
    if (m.type !== 'notify') return;

    for (const msg of m.messages || []) {
      const codes = extractInviteCodes(extractTextFromMessage(msg));

      for (const code of codes) {
        if (session.seen.has(code)) continue;

        session.seen.add(code);
        session.queue.push(createQueueEntry(session, code));
      }
    }
  };
}

async function processTick(session, userId, slot) {
  if (!session.queue.length) return false;

  // Resolve invite metadata before choosing. This lets the queue sort by
  // member count and distinguish open/locked groups before any join attempt.
  await hydrateQueue(session);

  // Remove links whose invite information could not be read.
  for (const entry of [...session.queue]) {
    if (entry.ready && entry.failedInfo) {
      removeEntry(session, entry);
    }
  }

  const entry = chooseNextEntry(session);

  if (!entry) {
    // Everything left is either below the minimum or has no usable metadata.
    for (const queued of [...session.queue]) {
      if (!queued.ready || queued.failedInfo) continue;

      const size = getInviteSize(queued.info);
      if (size < MIN_GROUP_SIZE) {
        session.skippedTooSmall++;
        removeEntry(session, queued);

        console.log(
          `[AUTOJOIN] Skipped (${size} members, under ${MIN_GROUP_SIZE}): Telegram ${userId} | Session ${slot} | ${queued.code} | ${queued.info?.subject || ''}`
        );
      }
    }

    return false;
  }

  const { code, info } = entry;
  const size = getInviteSize(info);
  const locked = isLockedGroup(info);

  removeEntry(session, entry);

  try {
    await session.sock.groupAcceptInvite(code);

    session.joinedCount++;
    session.joinedSinceReport++;
    session.joinedSinceRun++;

    if (locked) session.joinedLocked++;
    else session.joinedOpen++;

    console.log(
      `[AUTOJOIN] Joined: Telegram ${userId} | Session ${slot} | ${code} | ` +
      `${info?.subject || ''} (${size} members${locked ? ', locked' : ', open'})`
    );
  } catch (error) {
    console.error(
      `[AUTOJOIN] Failed: Telegram ${userId} | Session ${slot} | ${code} | ${error?.message || error}`
    );
  }

  session.ticksSinceReport++;

  if (session.ticksSinceReport >= REPORT_INTERVAL_TICKS) {
    const joinedThisWindow = session.joinedSinceReport;

    session.ticksSinceReport = 0;
    session.joinedSinceReport = 0;

    if (session.telegramApi) {
      session.telegramApi.sendMessage(
        userId,
        '🔄 AUTOJOIN UPDATE\n\n' +
        'Joined in the latest report window: ' + joinedThisWindow + '\n' +
        'Total joined since turning on: ' + session.joinedCount + '\n' +
        'Open joined: ' + session.joinedOpen + '\n' +
        'Locked joined: ' + session.joinedLocked +
        (session.skippedTooSmall
          ? '\nSkipped (under ' + MIN_GROUP_SIZE + ' members): ' + session.skippedTooSmall
          : '')
      ).catch(() => {});
    }
  }

  return true;
}

function scheduleNextTick(session, userId, slot, delay = JOIN_INTERVAL_MS) {
  session.timer = setTimeout(async () => {
    const key = sessionKey(userId, slot);

    if (autoJoinSessions.get(key) !== session) return;

    const joined = await processTick(session, userId, slot);

    if (autoJoinSessions.get(key) !== session) return;

    // Six successful joins represent 30 seconds of joining at one join
    // every 5 seconds. Then pause for 15 seconds.
    if (joined && session.joinedSinceRun >= JOINS_PER_RUN) {
      session.joinedSinceRun = 0;
      scheduleNextTick(session, userId, slot, RUN_DELAY_MS);
    } else {
      scheduleNextTick(session, userId, slot, JOIN_INTERVAL_MS);
    }
  }, delay);
}

// Queue invite codes discovered via /scan. If autojoin is already running
// for this session, they join the same prioritized queue; otherwise they are
// held until /autojoin is turned on.
export function queueInviteCodes(userId, slot, codes) {
  const key = sessionKey(userId, slot);
  const session = autoJoinSessions.get(key);
  const added = [];

  for (const code of codes) {
    if (session) {
      if (session.seen.has(code)) continue;
      session.seen.add(code);
      session.queue.push(createQueueEntry(session, code));
    } else {
      let queue = pendingQueues.get(key);

      if (!queue) {
        queue = new Set();
        pendingQueues.set(key, queue);
      }

      if (queue.has(code)) continue;
      queue.add(code);
    }

    added.push(code);
  }

  return added.length;
}

export function enableAutoJoin(sock, userId, slot = 1, telegramApi = null) {
  if (!sock?.ev) {
    throw new Error('Invalid WhatsApp socket.');
  }

  const key = sessionKey(userId, slot);

  if (autoJoinSessions.has(key)) {
    return false;
  }

  const seen = new Set();
  const queue = [];

  const pending = pendingQueues.get(key);
  let queuedCount = 0;

  if (pending && pending.size) {
    for (const code of pending) {
      seen.add(code);
      queuedCount++;
    }

    pendingQueues.delete(key);
  }

  const session = {
    sock,
    handler: null,
    seen,
    queue,
    joinedCount: 0,
    joinedSinceReport: 0,
    joinedSinceRun: 0,
    joinedOpen: 0,
    joinedLocked: 0,
    skippedTooSmall: 0,
    ticksSinceReport: 0,
    timer: null,
    telegramApi
  };

  // Build pending entries after the session exists so they can use its socket.
  if (pending && pending.size) {
    for (const code of pending) {
      session.queue.push(createQueueEntry(session, code));
    }
  }

  session.handler = makeHandler(session);
  sock.ev.on('messages.upsert', session.handler);

  autoJoinSessions.set(key, session);

  console.log(
    `[AUTOJOIN] Enabled: Telegram ${userId} | Session ${slot} | ` +
    '1 group/5s, 6 successful joins/30s, 15s pause, 75% open/25% locked, descending member priority'
  );

  scheduleNextTick(session, userId, slot);

  return { started: true, queuedCount: session.queue.length, builtInCount: 0 };
}

export function enableAutoLinks(sock, userId, slot = 1, telegramApi = null) {
  if (!sock?.ev) {
    throw new Error('Invalid WhatsApp socket.');
  }

  const key = sessionKey(userId, slot);

  if (autoLinkSessions.has(key)) {
    return false;
  }

  const session = {
    sock,
    handler: null,
    seen: new Set(),
    queue: [],
    joinedCount: 0,
    joinedSinceReport: 0,
    joinedSinceRun: 0,
    joinedOpen: 0,
    joinedLocked: 0,
    skippedTooSmall: 0,
    ticksSinceReport: 0,
    timer: null,
    telegramApi
  };

  const builtInCodes = getBuiltInInviteCodes();
  for (const code of builtInCodes) {
    if (session.seen.has(code)) continue;
    session.seen.add(code);
    session.queue.push(createQueueEntry(session, code));
  }

  autoLinkSessions.set(key, session);

  console.log(
    `[AUTOLINKS] Enabled: Telegram ${userId} | Session ${slot} | ` +
    `Built-in links queued: ${builtInCodes.length}`
  );

  scheduleAutoLinkTick(session, userId, slot);

  return { started: true, queuedCount: session.queue.length, builtInCount: builtInCodes.length };
}

function scheduleAutoLinkTick(session, userId, slot, delay = JOIN_INTERVAL_MS) {
  session.timer = setTimeout(async () => {
    const key = sessionKey(userId, slot);

    if (autoLinkSessions.get(key) !== session) return;

    const joined = await processTick(session, userId, slot);

    if (autoLinkSessions.get(key) !== session) return;

    if (joined && session.joinedSinceRun >= JOINS_PER_RUN) {
      session.joinedSinceRun = 0;
      scheduleAutoLinkTick(session, userId, slot, RUN_DELAY_MS);
    } else {
      scheduleAutoLinkTick(session, userId, slot, JOIN_INTERVAL_MS);
    }
  }, delay);
}

export function disableAutoLinks(userId, slot = 1) {
  const key = sessionKey(userId, slot);
  const session = autoLinkSessions.get(key);

  if (!session) return false;

  if (session.timer) clearTimeout(session.timer);
  autoLinkSessions.delete(key);

  console.log(`[AUTOLINKS] Disabled: Telegram ${userId} | Session ${slot}`);
  return true;
}

export function isAutoLinksEnabled(userId, slot = 1) {
  return autoLinkSessions.has(sessionKey(userId, slot));
}

export function getAutoLinksStatus(userId, slot = 1) {
  const session = autoLinkSessions.get(sessionKey(userId, slot));
  if (!session) return null;

  return {
    queued: session.queue.length,
    joined: session.joinedCount,
    skippedTooSmall: session.skippedTooSmall,
    joinedOpen: session.joinedOpen,
    joinedLocked: session.joinedLocked
  };
}

export function disableAutoJoin(userId, slot = 1) {
  const key = sessionKey(userId, slot);
  const session = autoJoinSessions.get(key);

  if (!session) {
    return false;
  }

  if (session.sock?.ev?.off) {
    session.sock.ev.off('messages.upsert', session.handler);
  }

  if (session.timer) {
    clearTimeout(session.timer);
  }

  autoJoinSessions.delete(key);

  console.log(
    `[AUTOJOIN] Disabled: Telegram ${userId} | Session ${slot}`
  );

  return true;
}

export function isAutoJoinEnabled(userId, slot = 1) {
  return autoJoinSessions.has(sessionKey(userId, slot));
}

export function getAutoJoinStatus(userId, slot = 1) {
  const session = autoJoinSessions.get(sessionKey(userId, slot));

  if (!session) {
    return null;
  }

  return {
    queued: session.queue.length,
    joined: session.joinedCount,
    skippedTooSmall: session.skippedTooSmall,
    joinedOpen: session.joinedOpen,
    joinedLocked: session.joinedLocked
  };
}

export function setAutoJoinAll(enabled) {
  autoJoinAllEnabled = Boolean(enabled);
}

export function isAutoJoinAllEnabled() {
  return autoJoinAllEnabled;
}

export function attachAutoJoinToSocket(sock, userId, slot = 1) {
  const key = sessionKey(userId, slot);
  const existing = autoJoinSessions.get(key);

  if (!existing) {
    if (autoJoinAllEnabled) {
      enableAutoJoin(sock, userId, slot, null);
      console.log(
        `[AUTOJOIN] Autojoin-all enabled: Telegram ${userId} | Session ${slot}`
      );
      return true;
    }
    return false;
  }

  if (existing.sock === sock) {
    return true;
  }

  if (existing.sock?.ev?.off) {
    existing.sock.ev.off('messages.upsert', existing.handler);
  }

  existing.sock = sock;
  existing.handler = makeHandler(existing);
  sock.ev.on('messages.upsert', existing.handler);

  console.log(
    `[AUTOJOIN] Reattached: Telegram ${userId} | Session ${slot}`
  );

  return true;
}
