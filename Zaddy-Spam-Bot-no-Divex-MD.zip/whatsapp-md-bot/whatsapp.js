import makeWASocket, {
  Browsers,
  DisconnectReason,
  fetchLatestBaileysVersion,
  useMultiFileAuthState
} from '@whiskeysockets/baileys'
import { Boom } from '@hapi/boom'
import fs from 'fs'
import path from 'path'
import { attachAutoJoinToSocket } from './autojoin.js'
import { attachGcLinkScanToSocket } from './commands/gclinkscan.js'

// One WhatsApp session per Telegram user, keyed by their Telegram chat id.
// Each user gets their own auth folder so their sessions never collide.
const sessions = new Map()

function authPath(userId) {
  return path.join('./auth', String(userId))
}

function getSession(userId) {
  userId = String(userId)
  let s = sessions.get(userId)
  if (!s) {
    s = { sock: null, phone: null, reconnecting: false, loggingOut: false, onConnect: null, notifiedConnected: false }
    sessions.set(userId, s)
  }
  return s
}

export async function connectWhatsApp(userId, number, onConnect, opts = {}) {
  userId = String(userId)
  const { isReconnect = false } = opts
  const session = getSession(userId)
  // This guard stops /pair from clobbering a session that's already live.
  // It must NOT apply to the internal auto-reconnect path below: Baileys
  // doesn't clear sock.user just because the socket closed (it's cached
  // account info that only changes when a new socket replaces it), so a
  // dead socket still has .user set. Without isReconnect, this check would
  // see that stale value, assume "already linked", and bail out before a
  // new socket is ever created — silently breaking auto-reconnect forever
  // until someone manually /logout + /pair.
  if (!isReconnect && session.sock?.user) return 'ALREADY_LINKED'

  if (onConnect) session.onConnect = onConnect

  session.phone = number.replace(/\D/g, '')
  const { state, saveCreds } = await useMultiFileAuthState(authPath(userId))

  const { version } = await fetchLatestBaileysVersion()

  const sock = makeWASocket({
    version,
    auth: state,
    browser: Browsers.macOS('Safari'),
    printQRInTerminal: false,
    syncFullHistory: false
  })
  session.sock = sock

  attachAutoJoinToSocket(sock, userId, 1)
  attachGcLinkScanToSocket(sock, userId, 1)

  sock.ev.on('creds.update', saveCreds)

  sock.ev.on('connection.update', ({ connection, lastDisconnect }) => {
    if (connection === 'open' && !session.notifiedConnected) {
      session.notifiedConnected = true
      session.onConnect?.()
    }

    if (connection === 'close') {
      if (session.loggingOut) return

      // Only auto-reconnect a session that had already finished pairing.
      // If pairing never completed and the socket drops, retrying
      // immediately just re-requests another pairing code — and if that
      // connection also drops quickly, it loops every few seconds,
      // hammering WhatsApp's pairing endpoint. That pattern gets the
      // IP/device flagged and rate-limited for every number, not just
      // the one in use. Safer to stop and let the user explicitly
      // retry with /pair.
      if (!state.creds.registered) return

      const status = new Boom(lastDisconnect?.error)?.output?.statusCode
      if (status !== DisconnectReason.loggedOut && session.phone && !session.reconnecting) {
        session.reconnecting = true
        setTimeout(async () => {
          session.reconnecting = false
          try { await connectWhatsApp(userId, session.phone, null, { isReconnect: true }) } catch (e) { console.error(e) }
        }, 3000)
      }
    }
  })

  if (!state.creds.registered) {
    await new Promise(r => setTimeout(r, 1500))
    return await sock.requestPairingCode(session.phone)
  }

  return 'ALREADY_LINKED'
}

export function getSocket(userId) {
  return sessions.get(String(userId))?.sock || null
}

// Every userId whose session is actually linked right now (sock.user set)
// — used by /blastall to find every connected WhatsApp account to post
// through, without the owner having to pick sessions one at a time.
export function getConnectedUserIds() {
  const ids = []
  for (const [userId, session] of sessions) {
    if (session.sock?.user) ids.push(userId)
  }
  return ids
}

export async function getGroups(userId) {
  const sock = getSocket(userId)
  if (!sock?.user) throw new Error('WhatsApp is not connected')
  const groups = await sock.groupFetchAllParticipating()
  return Object.values(groups).map(g => ({ id: g.id, subject: g.subject, announce: !!g.announce }))
}

export async function logoutWhatsApp(userId) {
  userId = String(userId)
  const session = getSession(userId)
  session.loggingOut = true
  session.phone = null
  session.reconnecting = false
  session.notifiedConnected = false

  if (session.sock) {
    try {
      await session.sock.logout()
    } catch (e) {
      console.error('Network logout failed (ignoring, clearing local session anyway):', e.message)
    }
    try { session.sock.end?.(undefined) } catch (e) {}
    session.sock = null
  }

  try {
    fs.rmSync(authPath(userId), { recursive: true, force: true })
  } catch (e) {
    console.error('Could not clear auth folder:', e.message)
  }

  session.loggingOut = false
}

// Every folder under ./auth that has actually finished pairing gets
// silently reconnected when the bot process starts — otherwise every
// restart would leave every previously-paired account disconnected until
// each user manually re-ran /pair. No Telegram notification is sent here
// (matches the previous behavior); connectWhatsApp's onConnect still fires
// its normal "linked successfully" message the moment the socket actually
// reopens for a session that was live at restart.
export async function loadSavedSessions() {
  const authRoot = './auth'

  if (!fs.existsSync(authRoot)) {
    return
  }

  const userIds = fs.readdirSync(authRoot, { withFileTypes: true })
    .filter(d => d.isDirectory())
    .map(d => d.name)

  for (const userId of userIds) {
    try {
      const { state } = await useMultiFileAuthState(authPath(userId))

      if (!state.creds.registered) {
        continue
      }

      const savedPhone = state.creds.me?.id?.split(/[:@]/)[0] || '0'

      console.log(`🔄 Reconnecting saved WhatsApp session: Telegram ${userId}`)

      await connectWhatsApp(userId, savedPhone, null, { isReconnect: true })

    } catch (error) {
      console.error(`Failed to reconnect saved session for ${userId}:`, error.message)
    }
  }
}
