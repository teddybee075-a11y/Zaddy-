// A group's `announce` flag is set when WhatsApp's "only admins can send
// messages" setting is on for that group. Broadcasting into one of these
// either fails outright or is unreliable (see the group-status admin-only
// investigation) — so these are filtered out entirely before broadcast
// group lists are built, rather than attempted and counted as failures.
export function getPostableGroupIds(groups) {
  return Object.keys(groups).filter(jid => !groups[jid]?.announce);
}

export function countAdminOnlyGroups(groups) {
  return Object.keys(groups).filter(jid => !!groups[jid]?.announce).length;
}
