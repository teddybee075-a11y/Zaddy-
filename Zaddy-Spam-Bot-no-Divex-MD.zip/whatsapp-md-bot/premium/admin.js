import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ADMINS_FILE = path.join(__dirname, '..', 'data', 'admins.json');
const OWNER_ID = '6265335081';

function ensureAdminsFile() {
  const dir = path.dirname(ADMINS_FILE);

  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }

  if (!fs.existsSync(ADMINS_FILE)) {
    fs.writeFileSync(
      ADMINS_FILE,
      JSON.stringify({ admins: [] }, null, 2)
    );
  }
}

function loadAdmins() {
  ensureAdminsFile();

  try {
    const data = JSON.parse(
      fs.readFileSync(ADMINS_FILE, 'utf8')
    );

    if (!Array.isArray(data.admins)) {
      data.admins = [];
    }

    data.admins = data.admins.map(String);

    return data;
  } catch {
    return { admins: [] };
  }
}

function saveAdmins(data) {
  ensureAdminsFile();

  fs.writeFileSync(
    ADMINS_FILE,
    JSON.stringify(
      {
        admins: [...new Set(data.admins.map(String))]
      },
      null,
      2
    )
  );
}

export function isAdmin(telegramId) {
  const id = String(telegramId);

  if (id === OWNER_ID) {
    return true;
  }

  return loadAdmins().admins.includes(id);
}

export function isActualAdmin(telegramId) {
  const id = String(telegramId);

  if (id === OWNER_ID) {
    return false;
  }

  return loadAdmins().admins.includes(id);
}

export function getAdmins() {
  return loadAdmins().admins;
}

export function addAdmin(telegramId) {
  const id = String(telegramId);

  if (id === OWNER_ID) {
    return false;
  }

  const data = loadAdmins();

  if (!data.admins.includes(id)) {
    data.admins.push(id);
    saveAdmins(data);
  }

  return true;
}

export function removeAdmin(telegramId) {
  const id = String(telegramId);

  if (id === OWNER_ID) {
    return false;
  }

  const data = loadAdmins();

  data.admins = data.admins.filter(
    adminId => adminId !== id
  );

  saveAdmins(data);

  return true;
}

export async function requireAdmin(ctx) {
  const userId = ctx?.from?.id;

  if (!userId) {
    return false;
  }

  if (isAdmin(userId)) {
    return true;
  }

  await ctx.reply(
    'Admin access required.'
  );

  return false;
}
