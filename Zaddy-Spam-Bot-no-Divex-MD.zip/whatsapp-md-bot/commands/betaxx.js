import { getPostableGroupIds, countAdminOnlyGroups } from '../groups.js';

export async function betaxxCommand(ctx, sock, setPendingBetaxx) {
  try {
    if (!sock?.user) {
      return ctx.reply('❌ WhatsApp is not connected.');
    }

    const allGroups = await sock.groupFetchAllParticipating();
    const groupIds = getPostableGroupIds(allGroups);
    const groups = allGroups;
    const skipped = countAdminOnlyGroups(allGroups);

    if (!groupIds.length) {
      return ctx.reply(
        skipped
          ? `❌ No postable WhatsApp groups found.\n\n(${skipped} group${skipped === 1 ? '' : 's'} skipped — only admins can message there.)`
          : '❌ No WhatsApp groups found.'
      );
    }

    const pending = {
      groupIds,
      groups,
      selected: [],
      stage: 'groups',
      message: ''
    };

    setPendingBetaxx(ctx.from.id, pending);

    let text = '🚀 BSTATUS — SELECT GROUPS\n\n';

    groupIds.forEach((jid, index) => {
      const name = groups[jid]?.subject || 'Unnamed group';
      text += `${index + 1}. ${name}\n`;
    });

    text +=
      '\nReply with the group numbers you want.\n' +
      'Example: 1,7,10\n\n' +
      'Then send the message you want to broadcast.';

    if (skipped) {
      text += `\n\n(${skipped} admin-only group${skipped === 1 ? '' : 's'} skipped — members can't message there.)`;
    }

    await ctx.reply(text);

  } catch (error) {
    console.error('BSTATUS ERROR:', error);

    await ctx.reply(
      `❌ BSTATUS failed.\n\n${error.message}`
    );
  }
}