export async function groupCheckCommand(ctx, sock) {
  try {
    if (!sock?.user) {
      return ctx.reply('❌ WhatsApp is not connected.');
    }

    const groups = await sock.groupFetchAllParticipating();
    const count = Object.keys(groups).length;

    await ctx.reply(
      `👥 GROUP CHECK\n\n` +
      `Your paired WhatsApp account is in *${count}* group${count === 1 ? '' : 's'}.`,
      { parse_mode: 'Markdown' }
    );

  } catch (error) {
    console.error('Group check error:', error);
    await ctx.reply('❌ I could not retrieve your WhatsApp groups.');
  }
}
