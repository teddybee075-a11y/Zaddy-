const activeBroadcasts = new Map();

// Aggregate send rate = CONCURRENCY / (DELAY_MS / 1000). Two lanes at
// 1.2s each means one lane hitting a slow network response doesn't
// stall the whole broadcast — the other lane keeps going.
const DELAY_MS = 2400;
const MAX_RETRIES = 3;

// Number of concurrent "lanes" sending at once. Each lane still paces
// itself at DELAY_MS between its own sends. This and DELAY_MS together
// set the aggregate rate WhatsApp's servers see from the account, so
// changing either is a real dial on ban risk, not a free performance
// knob — raise them together deliberately, not independently.
const CONCURRENCY = 2;

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function isRetryable(error) {
  const text = String(error?.message || '').toLowerCase();

  return (
    text.includes('timeout') ||
    text.includes('timed out') ||
    text.includes('connection') ||
    text.includes('closed') ||
    text.includes('socket') ||
    text.includes('network') ||
    text.includes('temporarily')
  );
}

export function isBroadcastRunning(userId) {
  return activeBroadcasts.has(String(userId));
}

export function getBroadcastStatus(userId) {
  const state = activeBroadcasts.get(String(userId));

  if (!state) {
    return null;
  }

  const percent = state.total
    ? Math.round((state.completed / state.total) * 100)
    : 0;

  return {
    running: state.running,
    total: state.total,
    completed: state.completed,
    success: state.success,
    failed: state.failed,
    remaining: state.total - state.completed,
    percent
  };
}

export function startBroadcastQueue({
  userId,
  sock,
  getSock,
  groups,
  createMessage,
  onProgress,
  onFinish,
  delayMs = DELAY_MS,
  concurrency = CONCURRENCY
}) {
  const key = String(userId);

  // getSock() re-fetches the live socket from the sessions map on every
  // attempt. A plain `sock` reference captured once at broadcast start
  // goes stale the moment the connection drops and reconnects: on close,
  // whatsapp.js's reconnect timer builds a brand-new socket object, but
  // Baileys never clears `.user` on the old, now-dead object. A captured
  // reference to it still passes `sock?.user` and sock.relayMessage() on
  // it resolves without throwing (there's just no live connection
  // underneath), so the broadcast reports "Sent" while nothing actually
  // reaches WhatsApp. Falling back to the static `sock` keeps old call
  // sites working, but any caller that can reconnect mid
  // broadcast should pass getSock instead.
  const resolveSock = () => (getSock ? getSock() : sock);

  if (activeBroadcasts.has(key)) {
    throw new Error(
      'A broadcast is already running for this WhatsApp session.'
    );
  }

  if (!resolveSock()?.user) {
    throw new Error('WhatsApp is not connected.');
  }

  if (!Array.isArray(groups) || groups.length === 0) {
    throw new Error('No groups selected.');
  }

  const state = {
    total: groups.length,
    completed: 0,
    success: 0,
    failed: 0,
    running: true
  };

  activeBroadcasts.set(key, state);

  let nextIndex = 0;

  async function sendOne(group) {
    let sent = false;

    for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
      try {
        const liveSock = resolveSock();

        if (!liveSock?.user) {
          throw new Error('WhatsApp connection lost.');
        }

        const message = await createMessage(group);

        await liveSock.relayMessage(
          group.jid,
          message.message,
          {
            messageId: message.key.id
          }
        );

        state.success++;
        sent = true;
        break;

      } catch (error) {
        console.error(
          '[BROADCAST] ' +
          group.name +
          ' attempt ' +
          attempt +
          '/' +
          MAX_RETRIES +
          ' failed:',
          error.message
        );

        if (
          attempt < MAX_RETRIES &&
          isRetryable(error)
        ) {
          await sleep(3000 * attempt);
        }
      }
    }

    if (!sent) {
      state.failed++;
    }

    state.completed++;

    console.log(
      '[BROADCAST] ' +
      state.completed +
      '/' +
      state.total +
      ' | Sent: ' +
      state.success +
      ' | Failed: ' +
      state.failed +
      ' | ' +
      group.name
    );

    onProgress?.(state, group);
  }

  // Each lane pulls the next unclaimed group from a shared index. This is
  // safe without locks: `nextIndex++` runs synchronously with no `await`
  // in between the read and the write, so two lanes can never claim the
  // same index — standard single-threaded-event-loop safety in JS.
  async function lane() {
    while (true) {
      const index = nextIndex++;

      if (index >= groups.length) {
        return;
      }

      await sendOne(groups[index]);

      if (nextIndex < groups.length) {
        await sleep(delayMs);
      }
    }
  }

  void (async () => {
    try {
      const laneCount = Math.min(concurrency, groups.length);
      await Promise.all(
        Array.from({ length: laneCount }, () => lane())
      );

    } catch (error) {
      console.error(
        '[BROADCAST] Fatal error:',
        error.message
      );

    } finally {
      state.running = false;
      activeBroadcasts.delete(key);

      onFinish?.(state);
    }
  })();

  return state;
}
