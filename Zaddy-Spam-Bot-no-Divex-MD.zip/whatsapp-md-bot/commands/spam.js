export function spamCommand(ctx) {
  ctx.reply(
    '📢 SPAM MENU\n\n' +
    '/bstatus - Broadcast to groups\n' +
    '/bprogress - Check a running broadcast\'s progress\n' +
    '/schedulebroadcast - Schedule a broadcast\n' +
    '/groupcheck - Check how many WhatsApp groups you\'re in\n' +
    '/blastall - (admin) Blast a message across every connected session\n' +
    '/announce - (owner) Message every Telegram user of this bot'
  );
}