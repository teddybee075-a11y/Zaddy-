import { getPostableGroupIds, countAdminOnlyGroups } from '../groups.js';

export function registerScheduleCommands(bot, {
  requireJoined,
  getUserSock,
  createSchedule,
  getSchedules,
  cancelSchedule
}) {
  const pending = new Map();

  function parseInterval(text) {
    const parts = String(text).trim().split(/\s+/);

    if (parts.length !== 2) return null;

    const amount = Number(parts[0]);
    const unit = parts[1].toLowerCase();

    if (!Number.isFinite(amount) || amount <= 0) return null;

    const units = {
      s: 1000,
      sec: 1000,
      secs: 1000,
      second: 1000,
      seconds: 1000,
      m: 60000,
      min: 60000,
      mins: 60000,
      minute: 60000,
      minutes: 60000,
      h: 3600000,
      hr: 3600000,
      hrs: 3600000,
      hour: 3600000,
      hours: 3600000
    };

    const multiplier = units[unit];

    if (!multiplier) return null;

    return {
      intervalMs: Math.round(amount * multiplier),
      label: amount + ' ' + unit
    };
  }

  bot.command('schedulebroadcast', async (ctx) => {
    if (!(await requireJoined(ctx))) return;

    const userId = ctx.from.id;
    const userSock = getUserSock(userId);

    if (!userSock?.user) {
      return ctx.reply(
        '❌ WhatsApp is not connected.\n\n' +
        'Use /pair first.'
      );
    }

    const commandText = ctx.message?.text || '';
    const space = commandText.indexOf(' ');
    const intervalText =
      space === -1 ? '' : commandText.substring(space + 1).trim();

    if (!intervalText) {
      return ctx.reply(
        '❌ Enter the broadcast interval.\n\n' +
        'Examples:\n' +
        '/schedulebroadcast 30 mins\n' +
        '/schedulebroadcast 1 hour\n' +
        '/schedulebroadcast 2 hours'
      );
    }

    const interval = parseInterval(intervalText);

    if (!interval) {
      return ctx.reply(
        '❌ Invalid interval.\n\n' +
        'Examples:\n' +
        '/schedulebroadcast 30 mins\n' +
        '/schedulebroadcast 1 hour\n' +
        '/schedulebroadcast 2 hours'
      );
    }

    try {
      let groups = null;
      let lastError = null;

      for (let attempt = 1; attempt <= 5; attempt++) {
        const currentSock = getUserSock(userId);

        if (!currentSock?.user) {
          await new Promise(resolve => setTimeout(resolve, 3000));
          continue;
        }

        try {
          groups = await currentSock.groupFetchAllParticipating();

          if (groups && typeof groups === 'object') {
            break;
          }
        } catch (error) {
          lastError = error;

          console.error(
            'SCHEDULE GROUP FETCH ATTEMPT ' + attempt + ':',
            error.message
          );

          if (attempt < 5) {
            await new Promise(resolve => setTimeout(resolve, 4000));
          }
        }
      }

      if (!groups) {
        throw lastError || new Error('Unable to load WhatsApp groups.');
      }

      const groupIds = getPostableGroupIds(groups);
      const skippedCount = countAdminOnlyGroups(groups);

      if (!groupIds.length) {
        return ctx.reply(
          skippedCount
            ? `❌ No postable WhatsApp groups found.\n\n(${skippedCount} group${skippedCount === 1 ? '' : 's'} skipped — only admins can message there.)`
            : '❌ No WhatsApp groups found.'
        );
      }

      console.log(
        'SCHEDULE BROADCAST: Loaded ' + groupIds.length + ' postable WhatsApp groups (' + skippedCount + ' admin-only skipped).'
      );

      pending.set(userId, {
        stage: 'destination',
        intervalMs: interval.intervalMs,
        intervalLabel: interval.label,
        groupIds,
        groups,
        selected: [],
        message: ''
      });

      return ctx.reply(
        '🔁 RECURRING BROADCAST\n\n' +
        '⏱️ Every ' + interval.label + '\n\n' +
        (skippedCount ? '🔒 ' + skippedCount + ' admin-only group' + (skippedCount === 1 ? '' : 's') + ' skipped.\n\n' : '') +
        '📍 Choose destination:\n\n' +
        '1️⃣ All groups\n' +
        '2️⃣ Selected groups\n\n' +
        'Reply with 1 or 2.'
      );
      } catch (error) {
      console.error('SCHEDULE BROADCAST ERROR:', error);

      return ctx.reply(
        '❌ Could not load WhatsApp groups.\n\n' +
        error.message
      );
    }
  });

  bot.command('scheduled', async (ctx) => {
    if (!(await requireJoined(ctx))) return;

    const schedules = getSchedules(ctx.from.id);

    if (!schedules.length) {
      return ctx.reply(
        '📅 No active recurring broadcasts.'
      );
    }

    let text = '🔁 ACTIVE RECURRING BROADCASTS\n\n';

    schedules.forEach((schedule, index) => {
      const intervalMinutes = schedule.intervalMs / 60000;

      let intervalText;

      if (intervalMinutes >= 60 && intervalMinutes % 60 === 0) {
        intervalText = (intervalMinutes / 60) + ' hour(s)';
      } else {
        intervalText = intervalMinutes + ' minute(s)';
      }

      text +=
        '━━━━━━━━━━━━━━━━\n' +
        '🔹 ' + (index + 1) + '\n\n' +
        '🆔 ' + schedule.id + '\n' +
        '⏱️ Every ' + intervalText + '\n' +
        '▶️ Next: ' +
        new Date(schedule.scheduledAt).toLocaleString() + '\n' +
        '👥 Groups: ' + schedule.groupIds.length + '\n' +
        '📝 ' + schedule.message + '\n\n';
    });

    return ctx.reply(text);
  });

  bot.command('cancelschedule', async (ctx) => {
    if (!(await requireJoined(ctx))) return;

    const parts = (ctx.message?.text || '').trim().split(/\s+/);
    const id = parts[1];

    if (!id) {
      return ctx.reply(
        '❌ Enter the schedule ID.\n\n' +
        'Example:\n' +
        '/cancelschedule abc123'
      );
    }

    const cancelled = cancelSchedule(ctx.from.id, id);

    if (!cancelled) {
      return ctx.reply(
        '❌ Schedule not found or already cancelled.'
      );
    }

    return ctx.reply(
      '✅ RECURRING BROADCAST CANCELLED\n\n' +
      '🆔 ' + id
    );
  });

  return async function handleScheduleText(ctx) {
    const userId = ctx.from.id;
    const state = pending.get(userId);

    if (!state) return false;

    const input = String(ctx.message?.text || '').trim();

    if (state.stage === 'destination') {
    if (input === "1") {
      state.selected = [];

      for (const jid of state.groupIds) {
        const name = state.groups[jid]?.subject || "Unnamed group";

        state.selected.push({
          jid,
          name,
          profilePicture: null
        });
      }

      state.stage = "message";

      await ctx.reply(
        "ALL GROUPS SELECTED\n\n" +
        "Send the message or link."
      );

      return true;
      }

      if (input === '2') {
        state.stage = 'groups';

        let text =
          '👥 SELECT GROUPS\n\n';

        state.groupIds.forEach((jid, index) => {
          text +=
            (index + 1) + '. ' +
            (state.groups[jid]?.subject || 'Unnamed group') +
            '\n';
        });

        text +=
          '\n📌 Send group numbers separated by commas.\n\n' +
          'Example: 1,7,10';

        await ctx.reply(text);

        return true;
      }

      await ctx.reply(
        '❌ Invalid destination.\n\n' +
        '1️⃣ All groups\n' +
        '2️⃣ Selected groups'
      );

      return true;
    }

    if (state.stage === 'groups') {
      const numbers = input
        .split(',')
        .map(value => Number(value.trim()));

      if (
        !numbers.length ||
        numbers.some(
          n =>
            !Number.isInteger(n) ||
            n < 1 ||
            n > state.groupIds.length
        )
      ) {
        await ctx.reply(
          '❌ Invalid selection.\n\n' +
          'Example: 1,7,10'
        );

        return true;
      }

      const uniqueNumbers = [...new Set(numbers)];

    state.selected = [];

    for (const n of uniqueNumbers) {
      const jid = state.groupIds[n - 1];
      const name = state.groups[jid]?.subject || "Unnamed group";
      let profilePicture = null;

      try {
        profilePicture = await getUserSock(userId).profilePictureUrl(jid, "image");
      } catch (error) {
        console.log("[SCHEDULE] Could not get group picture for " + name + ": " + error.message);
      }

      state.selected.push({
        jid,
        name,
        profilePicture
      });
    }

      state.stage = 'message';

      await ctx.reply(
        '✅ ' + state.selected.length + ' GROUP(S) SELECTED\n\n' +
        '📝 Send the message or link.'
      );

      return true;
    }

    if (state.stage === 'message') {
      if (!input) {
        await ctx.reply(
          '❌ The message cannot be empty.'
        );

        return true;
      }

      state.message = input;

      const firstRun =
        new Date(Date.now() + state.intervalMs);

      const schedule = createSchedule({
        userId,
        message: state.message,
        scheduledAt: firstRun.toISOString(),
        intervalMs: state.intervalMs,
        groupIds: state.selected.map(group => group.jid),
        groups: state.selected
      });

      pending.delete(userId);

      await ctx.reply(
        '✅ RECURRING BROADCAST CREATED\n\n' +
        '🆔 ' + schedule.id + '\n\n' +
        '🔁 Every ' + state.intervalLabel + '\n' +
        '▶️ First run: ' + firstRun.toLocaleString() + '\n' +
        '👥 Groups: ' + schedule.groupIds.length + '\n\n' +
        '📝 ' + schedule.message + '\n\n' +
        'Use /scheduled to view it.\n' +
        'Use /cancelschedule ' + schedule.id + ' to stop it.'
      );

      return true;
    }

    return false;
  };
}
