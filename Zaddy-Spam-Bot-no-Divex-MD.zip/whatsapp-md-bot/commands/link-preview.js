import axios from 'axios'
import * as cheerio from 'cheerio'

const USER_AGENT =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'

const INVITE_HOSTS = ['t.me', 'chat.whatsapp.com']

function isInviteLink(url) {
  try {
    const { hostname } = new URL(url)
    return INVITE_HOSTS.some((h) => hostname === h || hostname.endsWith(`.${h}`))
  } catch {
    return false
  }
}

export function extractInviteCode(url) {
  try {
    const { hostname, pathname } = new URL(url)
    if (hostname !== 'chat.whatsapp.com' && !hostname.endsWith('.chat.whatsapp.com')) return null
    const code = pathname.replace(/^\/+/, '').split('/')[0]
    return code || null
  } catch {
    return null
  }
}

export function extractUrl(text) {
  const match = String(text || '').match(/https?:\/\/[^\s]+/i)
  if (!match) return null
  return match[0].replace(/[),.!?]+$/, '')
}

function extractTelegramUsername(url) {
  try {
    const { hostname, pathname } = new URL(url)
    if (hostname !== 't.me' && !hostname.endsWith('.t.me')) return null

    const segment = pathname.replace(/^\/+/, '').split('/')[0]

    // Skip forms that aren't a resolvable public @username:
    // private invites (+hash / joinchat/hash), the /s/ preview mirror,
    // and folder links (/addlist/...).
    if (!segment || segment.startsWith('+') || segment === 'joinchat' || segment === 's' || segment === 'addlist') {
      return null
    }

    return segment
  } catch {
    return null
  }
}

// Ask Telegram's own Bot API for the chat's real title/description/photo
// instead of scraping the t.me HTML page. HTML scraping from a datacenter
// IP gets rate-limited/blocked by Telegram far more aggressively than a
// residential IP, which is why t.me previews can silently fail while
// chat.whatsapp.com ones keep working. getChat has no such restriction —
// it just needs the bot to be able to resolve the @username (public chat,
// or one the bot is already a member/admin of).
export async function getTelegramChatPreview(telegramApi, url) {
  if (!telegramApi) return null

  const username = extractTelegramUsername(url)
  if (!username) return null

  try {
    const chat = await telegramApi.getChat('@' + username)

    const title = chat.title || [chat.first_name, chat.last_name].filter(Boolean).join(' ') || username
    const description = chat.description || chat.bio || ''

    let image = null

    if (chat.photo?.big_file_id || chat.photo?.small_file_id) {
      try {
        const fileId = chat.photo.big_file_id || chat.photo.small_file_id
        const fileLink = await telegramApi.getFileLink(fileId)
        image = fileLink.toString()
      } catch {
        image = null
      }
    }

    return { url, title, description, image, isInvite: true }
  } catch (error) {
    console.error(`TELEGRAM getChat ERROR (${url}):`, error.message)
    return null
  }
}

export async function getLinkPreview(input, telegramApi) {
  const url = extractUrl(input) || (isValidUrl(input) ? input : null)
  if (!url) return null

  if (telegramApi) {
    const telegramPreview = await getTelegramChatPreview(telegramApi, url)
    if (telegramPreview) return telegramPreview
  }

  const invite = isInviteLink(url)
  const MAX_ATTEMPTS = 3

  for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
    try {
      const { data } = await axios.get(url, {
        timeout: 10000,
        maxRedirects: 5,
        headers: {
          'User-Agent': USER_AGENT,
          'Accept-Language': 'en-US,en;q=0.9'
        }
      })

      const $ = cheerio.load(data)

      const title =
        $('meta[property="og:title"]').attr('content')?.trim() ||
        $('meta[name="twitter:title"]').attr('content')?.trim() ||
        $('title').text()?.trim() ||
        url

      const description =
        $('meta[property="og:description"]').attr('content')?.trim() ||
        $('meta[name="twitter:description"]').attr('content')?.trim() ||
        $('meta[name="description"]').attr('content')?.trim() ||
        ''

      const rawImage =
        $('meta[property="og:image"]').attr('content') ||
        $('meta[name="twitter:image"]').attr('content') ||
        null

      const image = rawImage ? new URL(rawImage, url).href : null

      if (invite && !title && !image) return null

      return { url, title, description, image, isInvite: invite }
    } catch (error) {
      const status = error.response?.status

      if (status === 429 && attempt < MAX_ATTEMPTS) {
        const delayMs = attempt * 2000
        console.error(`LINK PREVIEW ERROR: 429 for ${url} — retrying in ${delayMs}ms (attempt ${attempt}/${MAX_ATTEMPTS})`)
        await new Promise(r => setTimeout(r, delayMs))
        continue
      }

      console.error(`LINK PREVIEW ERROR (${url}):`, error.message)

      if (invite) return null

      return { url, title: url, description: '', image: null, isInvite: false }
    }
  }
}

function isValidUrl(str) {
  try {
    new URL(str)
    return true
  } catch {
    return false
  }
}

export async function fetchPreviewImageBuffer(imageUrl) {
  if (!imageUrl) return null

  try {
    const { data } = await axios.get(imageUrl, {
      responseType: 'arraybuffer',
      timeout: 10000,
      headers: { 'User-Agent': USER_AGENT }
    })

    return Buffer.from(data)
  } catch (error) {
    console.error('LINK PREVIEW IMAGE ERROR:', error.message)
    return null
  }
}
