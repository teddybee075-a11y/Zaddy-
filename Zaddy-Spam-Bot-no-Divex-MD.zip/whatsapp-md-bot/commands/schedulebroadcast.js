import fs from 'fs';
import path from 'path';

const DATA_DIR = path.join(process.cwd(), 'data');
const FILE = path.join(DATA_DIR, 'scheduled_broadcasts.json');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

if (!fs.existsSync(FILE)) {
  fs.writeFileSync(FILE, '[]');
}

function loadSchedules() {
  try {
    return JSON.parse(fs.readFileSync(FILE, 'utf8'));
  } catch {
    return [];
  }
}

function saveSchedules(schedules) {
  fs.writeFileSync(FILE, JSON.stringify(schedules, null, 2));
}

export function createSchedule({
  userId,
  message,
  scheduledAt,
  intervalMs,
  groupIds,
  groups
}) {
  const schedules = loadSchedules();

  const id = Math.random().toString(36).slice(2, 5).toUpperCase();

  const schedule = {
    id,
    userId,
    message,
    scheduledAt,
    intervalMs,
    groupIds,
    groups,
    status: 'pending',
    createdAt: new Date().toISOString()
  };

  schedules.push(schedule);
  saveSchedules(schedules);

  return schedule;
}

export function getSchedules(userId) {
  return loadSchedules().filter(
    schedule =>
      String(schedule.userId) === String(userId) &&
      schedule.status === 'pending'
  );
}

export function cancelSchedule(userId, id) {
  const schedules = loadSchedules();

  const schedule = schedules.find(
    item =>
      String(item.userId) === String(userId) &&
      item.id === id &&
      item.status === 'pending'
  );

  if (!schedule) return false;

  schedule.status = 'cancelled';
  saveSchedules(schedules);

  return true;
}

export function getDueSchedules() {
  const now = Date.now();

  return loadSchedules().filter(
    schedule =>
      schedule.status === 'pending' &&
      new Date(schedule.scheduledAt).getTime() <= now
  );
}

export function markScheduleCompleted(id, nextRunAt) {
  const schedules = loadSchedules();

  const schedule = schedules.find(
    item => item.id === id
  );

  if (!schedule) return;

  schedule.scheduledAt = nextRunAt;
  schedule.status = 'pending';

  saveSchedules(schedules);
}

export function markScheduleFailed(id, nextRunAt) {
  const schedules = loadSchedules();

  const schedule = schedules.find(
    item => item.id === id
  );

  if (!schedule) return;

  schedule.scheduledAt = nextRunAt;
  schedule.status = 'pending';

  saveSchedules(schedules);
}
