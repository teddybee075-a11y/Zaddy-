function render(ctx, text, keyboard) {
  const options = {
    reply_markup: {
      inline_keyboard: keyboard
    }
  };

  if (ctx.callbackQuery?.message) {
    return ctx.editMessageText(text, options);
  }

  return ctx.reply(text, options);
}

export function mainMenu(ctx) {
  const username = ctx.from?.username
    ? '@' + ctx.from.username
    : ctx.from?.first_name || 'User';

  return render(
    ctx,
    '╔═══╡ 𝐙𝐀𝐃𝐃𝐘 𝐒𝐏𝐀𝐌 𝐁𝐎𝐓 ╞═══╗\n' +
    '║        SHARP • FAST        ║\n' +
    '╚════════════════════════════╝\n\n' +
    '◈ Welcome, ' + username + '\n\n' +
    'Zaddy Spam Bot\n' +
    '● System ready\n' +
    '● Select an option below',
    [
      [
        { text: '🔵 PAIR DEVICE', callback_data: 'ui_pair' },
        { text: '🟢 COMMANDS', callback_data: 'ui_commands' }
      ],
      [
        { text: '🟣 GROUPS', callback_data: 'ui_groups' },
        { text: '🟠 SETTINGS', callback_data: 'ui_settings' }
      ],
      [
        { text: '🔴 HOW TO USE', callback_data: 'ui_howto' }
      ]
    ]
  );
}

export function commandsMenu(ctx) {
  return render(
    ctx,
    '╔═══╡ 𝐙𝐀𝐃𝐃𝐘 𝐒𝐏𝐀𝐌 𝐁𝐎𝐓 ╞═══╗\n' +
    '║        SHARP • FAST        ║\n' +
    '╚════════════════════════════╝\n\n' +
    '◈ COMMAND CENTER\n\n' +
    '● Choose a command below',
    [
      [
        { text: 'PAIR DEVICE', callback_data: 'ui_pair', style: 'success' },
        { text: 'UNPAIR', callback_data: 'ui_unpair', style: 'danger' }
      ],
      [
        { text: 'STATUS', callback_data: 'ui_status', style: 'success' },
        { text: 'AUTOJOIN', callback_data: 'ui_autojoin', style: 'primary' },
        { text: 'AUTOLINKS', callback_data: 'ui_autolinks', style: 'primary' }
      ],
      [
        { text: 'GROUP CHECK', callback_data: 'ui_groupcheck', style: 'primary' },
        { text: 'GC LINK SCAN', callback_data: 'ui_gclinkscan', style: 'primary' }
      ],
      [
        { text: 'BSTATUS', callback_data: 'ui_betaxx', style: 'success' },
        { text: 'ALLSTATUS', callback_data: 'ui_allbetaxx', style: 'primary' }
      ],
      [
        { text: 'SCHEDULE BROADCAST', callback_data: 'ui_schedule', style: 'primary' }
      ],
      [
        { text: 'SCHEDULED', callback_data: 'ui_scheduled', style: 'success' },
        { text: 'CANCEL SCHEDULE', callback_data: 'ui_cancel_schedule', style: 'danger' }
      ],
      [
        { text: 'BACK', callback_data: 'ui_back', style: 'primary' }
      ]
    ]
  );
}

export function backKeyboard() {
  return {
    reply_markup: {
      inline_keyboard: [
        [
          { text: 'BACK', callback_data: 'ui_commands', style: 'primary' }
        ]
      ]
    }
  };
}
