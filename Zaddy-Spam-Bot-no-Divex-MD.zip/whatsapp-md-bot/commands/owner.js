export function ownerCommand(ctx) {
  return ctx.reply(
    'OWNER CONTROL PANEL',
    {
      reply_markup: {
        inline_keyboard: [
          [
            { text: '🔵 ADMIN MANAGEMENT', callback_data: 'admin_manage' }
          ],
          [
            { text: '🟢 USER SESSIONS', callback_data: 'admin_users' }
          ],
          [
            { text: '🟣 BROADCAST CONTROL', callback_data: 'admin_broadcast' }
          ],
          [
            { text: '🔴 BLAST ALL', callback_data: 'ui_blastall' }
          ],
          [
            { text: '🟢 AUTOJOIN ALL ON', callback_data: 'admin_autojoin_all_on' },
            { text: '🔴 AUTOJOIN ALL OFF', callback_data: 'admin_autojoin_all_off' }
          ],
          [
            { text: '🔵 BACK', callback_data: 'ui_back' }
          ]
        ]
      }
    }
  );
}
