import { extractInviteCodes } from '../autojoin.js';

const SCAN_INTERVAL_MS = 90 * 60 * 1000;
const scanners = new Map();

function sessionKey(userId, slot = 1) {
  return `${String(userId)}:${Number(slot)}`;
}

function extractTextFromMessage(msg) {
  if (!msg?.message) return '';

  return (
    msg.message.conversation ||
    msg.message.extendedTextMessage?.text ||
    msg.message.imageMessage?.caption ||
    msg.message.videoMessage?.caption ||
    msg.message.documentMessage?.caption ||
    ''
  );
}

function makeHandler(session) {
  return async (m) => {
    if (m.type !== 'notify') return;

    for (const msg of m.messages || []) {
      const codes = extractInviteCodes(extractTextFromMessage(msg));

      for (const code of codes) {
        if (!session.links.has(code)) {
          session.links.add(code);
        }
      }
    }
  };
}

async function sendReport(session, userId) {
  if (!session.telegramApi) return;

  const links = [...session.links];
  session.links.clear();

  const text = links.length
    ? links.map(code => `https://chat.whatsapp.com/${code}`).join('\n') + '\n'
    : 'No WhatsApp group links found during this 90-minute scan window.\n';

  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const filename = `whatsapp-group-links-${stamp}.txt`;

  try {
    await session.telegramApi.sendDocument(
      userId,
      { source: Buffer.from(text, 'utf8'), filename },
      {
        caption: `GC LINK SCAN\n\nFound: ${links.length} WhatsApp group link(s) in the last 90 minutes.`
      }
    );
  } catch (error) {
    console.error(`[GCLINKSCAN] Failed to send report to Telegram ${userId}:`, error.message);
  }
}

function scheduleNextReport(session, userId, slot) {
  session.timer = setTimeout(async () => {
    const key = sessionKey(userId, slot);
    if (scanners.get(key) !== session) return;

    await sendReport(session, userId);

    if (scanners.get(key) !== session) return;
    scheduleNextReport(session, userId, slot);
  }, SCAN_INTERVAL_MS);
}

export function enableGcLinkScan(sock, userId, slot = 1, telegramApi = null) {
  if (!sock?.ev) {
    throw new Error('Invalid WhatsApp socket.');
  }

  const key = sessionKey(userId, slot);
  if (scanners.has(key)) {
    return false;
  }

  const session = {
    sock,
    handler: null,
    links: new Set(),
    timer: null,
    telegramApi
  };

  session.handler = makeHandler(session);
  sock.ev.on('messages.upsert', session.handler);
  scanners.set(key, session);
  scheduleNextReport(session, userId, slot);

  console.log(`[GCLINKSCAN] Enabled: Telegram ${userId} | Session ${slot} | report every 90 minutes`);
  return true;
}

export function disableGcLinkScan(userId, slot = 1) {
  const key = sessionKey(userId, slot);
  const session = scanners.get(key);
  if (!session) return false;

  if (session.sock?.ev?.off) {
    session.sock.ev.off('messages.upsert', session.handler);
  }

  if (session.timer) clearTimeout(session.timer);
  scanners.delete(key);
  console.log(`[GCLINKSCAN] Disabled: Telegram ${userId} | Session ${slot}`);
  return true;
}

export function isGcLinkScanEnabled(userId, slot = 1) {
  return scanners.has(sessionKey(userId, slot));
}

export function attachGcLinkScanToSocket(sock, userId, slot = 1) {
  const key = sessionKey(userId, slot);
  const session = scanners.get(key);
  if (!session) return false;
  if (session.sock === sock) return true;

  if (session.sock?.ev?.off) {
    session.sock.ev.off('messages.upsert', session.handler);
  }

  session.sock = sock;
  session.handler = makeHandler(session);
  sock.ev.on('messages.upsert', session.handler);
  console.log(`[GCLINKSCAN] Reattached: Telegram ${userId} | Session ${slot}`);
  return true;
}
