import { startBroadcastQueue, isBroadcastRunning } from './broadcast-queue.js';
import { generateWAMessageFromContent, generateWAMessageContent, prepareWAMessageMedia } from "@whiskeysockets/baileys";
import { getLinkPreview } from './link-preview.js';

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

export function startScheduleWorker({
  getDueSchedules,
  getUserSock,
  markScheduleCompleted,
  markScheduleFailed,
  telegramApi
}) {
  let running = false;

  async function processSchedules() {
    if (running) return;

    running = true;

    try {
      const schedules = getDueSchedules();

      for (const schedule of schedules) {
        try {
          const userSock =
            getUserSock(schedule.userId);

          if (!userSock?.user) {
            console.log(
              '[SCHEDULE] WhatsApp not connected for ' +
              schedule.id
            );
            continue;
          }

          if (
            !Array.isArray(schedule.groups) ||
            !schedule.groups.length
          ) {
            const nextRun =
              new Date(
                Date.now() + schedule.intervalMs
              ).toISOString();

            markScheduleFailed(
              schedule.id,
              nextRun
            );

            continue;
          }

          /*
           * Wait for an existing BSTATUS/ALLSTATUS
           * broadcast to finish.
           */
          let waitCount = 0;

          while (isBroadcastRunning(schedule.userId)) {
            waitCount++;

            console.log(
              '[SCHEDULE] Waiting for active broadcast. ' +
              'Schedule: ' +
              schedule.id +
              ' | Wait: ' +
              waitCount
            );

            await sleep(5000);

            /*
             * Safety limit: do not wait forever.
             */
            if (waitCount >= 720) {
              throw new Error(
                'Another broadcast has been running for too long.'
              );
            }
          }

          console.log(
            '[SCHEDULE] Starting ' +
            schedule.id +
            ' for ' +
            schedule.groups.length +
            ' groups.'
          );

          // Prepare the preview ONCE per schedule run — not once per
          // group, which would re-fetch/re-scrape the same link once for
          // every single group in the broadcast. Same approach as
          // BSTATUS/ALLSTATUS/BLAST ALL: any URL in the message, not
          // just WhatsApp/Telegram invite links specifically.
          let previewContent = null;

          try {
            const preview = await getLinkPreview(schedule.message, telegramApi);

            if (preview?.title || preview?.image) {
              let imageMessage;

              if (preview.image) {
                try {
                  ({ imageMessage } = await prepareWAMessageMedia(
                    { image: { url: preview.image } },
                    { upload: userSock.waUploadToServer, mediaTypeOverride: 'thumbnail-link' }
                  ));
                } catch (imgError) {
                  console.log('[SCHEDULE] Preview image upload failed, continuing without thumbnail:', imgError.message);
                }
              }

              previewContent = await generateWAMessageContent(
                {
                  text: schedule.message,
                  linkPreview: {
                    'matched-text': preview.url,
                    title: preview.title || preview.url,
                    description: preview.description,
                    jpegThumbnail: imageMessage?.jpegThumbnail,
                    highQualityThumbnail: imageMessage
                  }
                },
                {
                  getUrlInfo: async () => ({
                    'matched-text': preview.url,
                    title: preview.title || preview.url,
                    description: preview.description,
                    jpegThumbnail: imageMessage?.jpegThumbnail,
                    highQualityThumbnail: imageMessage
                  })
                }
              );

              console.log('[SCHEDULE] Preview prepared once.');
            }
          } catch (error) {
            console.log('[SCHEDULE] Preview unavailable:', error.message);
          }

          startBroadcastQueue({
            userId: schedule.userId,
            sock: userSock,
            getSock: () => getUserSock(schedule.userId),
            groups: schedule.groups,

            createMessage: async (group) => {
              if (previewContent) {
                return generateWAMessageFromContent(
                  group.jid,
                  {
                    groupStatusMessageV2: {
                      message: previewContent
                    }
                  },
                  {}
                );
              }

              return generateWAMessageFromContent(
                group.jid,
                {
                  groupStatusMessageV2: {
                    message: { conversation: schedule.message }
                  }
                },
                {}
              );
            },
            onProgress: (state) => {
              if (
                state.completed % 25 === 0 ||
                state.completed === state.total
              ) {
                console.log(
                  '[SCHEDULE] ' +
                  schedule.id +
                  ' progress: ' +
                  state.completed +
                  '/' +
                  state.total +
                  ' | Sent: ' +
                  state.success +
                  ' | Failed: ' +
                  state.failed
                );
              }
            },

            onFinish: async (state) => {
              const nextRun =
                new Date(
                  Date.now() +
                  schedule.intervalMs
                ).toISOString();

              if (state.success > 0) {
                markScheduleCompleted(
                  schedule.id,
                  nextRun
                );
              } else {
                markScheduleFailed(
                  schedule.id,
                  nextRun
                );
              }

              console.log(
                '[SCHEDULE] Finished ' +
                schedule.id +
                ' | Sent: ' +
                state.success +
                ' | Failed: ' +
                state.failed +
                ' | Total: ' +
                state.total +
                ' | Next: ' +
                nextRun
              );
            }
          });

        } catch (error) {
          console.error(
            '[SCHEDULE] Failed ' +
            schedule.id +
            ':',
            error.message
          );

          const nextRun =
            new Date(
              Date.now() +
              schedule.intervalMs
            ).toISOString();

          markScheduleFailed(
            schedule.id,
            nextRun
          );
        }
      }

    } catch (error) {
      console.error(
        '[SCHEDULE] WORKER ERROR:',
        error.message
      );

    } finally {
      running = false;
    }
  }

  processSchedules();

  return setInterval(
    processSchedules,
    30 * 1000
  );
}
